# VisualpluginClient
该工具运行在Windows系统，用于展示AI_EXPRESS的视频数据和智能数据。

## 配置说明
该工具提供config.json文件，客户可根据自身需求修改配置。

ip为设备ip地址，solution_type字段区分设备端运行的智能算法类型，0表示face,1表示body,2表示vehicle，用户可根据实际运行情况修改这两个字段。其余字段一般情况无需修改。
```
{
  "mode": 2,
  "data": {
  	"solution_mode": 0,
    "path": "localdata",
    "ip": "10.64.35.50",
    "port": 556,
    "yuv_path": "/dev/shm/foo_30M",
    "domain": [
      {
        "name": "X2BIF001",
        "id": 0,
        "path": "/dev/x2_bif"
      },
      {
        "name": "X2SD001",
        "id": 1,
        "path": "/dev/x2_sd"
      }
    ]
  },
  "policy": {
    "width": 1920,
    "height": 1080,
    "sync": 0,
    "smart_size": 2048,
    "cache_size": 4
  },
  "render": {
    "default_color": "0xff0000ff",
    "id": {
      "on": 0,
      "color": "0xff0000ff",
      "font_size": 16
    },
    "head": {
      "on": 0,
      "color": "0xff0000ff",
      "width": 5
    },
    "body": {
      "on": 0,
      "color": "0xff0000ff",
      "width": 5
    },
    "skeleton": {
      "on": 0,
      "color": "0xff0000ff",
      "width": 5
    }
  }
}
```

## 注意事项
该工具采用基于tcp的rtsp协议与设备进行数据传输，若设备端（即服务端）在未收到工具端的关闭请求而自行退出，由于超时机制，端口需等待1min左右才能释放，所以在同一终端重启设备的solution需等待1分钟左右，若重新打开新的终端则无需等待。若关闭工具端，则会向服务端发送关闭请求，服务端也会主动释放端口，这种情况下重启solution也无需等待。
