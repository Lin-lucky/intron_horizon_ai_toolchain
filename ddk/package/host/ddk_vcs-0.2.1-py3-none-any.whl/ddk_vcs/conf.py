# -*- coding: utf-8 -*-

#  Copyright (c) 2021 Horizon Robotics.All Rights Reserved.
#  #
#  The material in this file is confidential and contains trade secrets
#  of Horizon Robotics Inc. This is proprietary information owned by
#  Horizon Robotics Inc. No part of this work may be disclosed,
#  reproduced, copied, transmitted, or used in any way for any purpose,
#  without the express written permission of Horizon Robotics Inc.
#

import os

HOME_PATH = os.path.expanduser('~')

HORIZON_LIB_PATH = os.path.join(HOME_PATH, '.horizon')

DDK_PATH = os.path.join(HORIZON_LIB_PATH, "ddk")

VCS_PATH = os.path.join(DDK_PATH, ".vcs")

PATCH_TMP_PATH = os.path.join(VCS_PATH, '.patch_tmp')

XJ3_AARCH64_PATH = os.path.join(DDK_PATH, 'xj3_aarch64')

XJ3_X86_64_GCC_PATH = os.path.join(DDK_PATH, 'xj3_x86_64_gcc_4.8.5')

HOST_PACKAGE_JSON = os.path.join(VCS_PATH, 'host_package.json')

aarch64_packages = ['appsdk',
                    'bpu_predict',
                    'dnn',
                    'hobotsdk',
                    'image_utils',
                    'model_inference',
                    'rtsp_server',
                    'uvc_server',
                    'video_source',
                    'xproto',
                    'xstream']

x86_list_packages = ['bpu_predict', 'hobotsdk', 'xproto', 'xstream', 'dnn_x86']

PATCH_CONFIG_YAML = {
    "discription": "",
    "packages": {
        "xj3_aarch64": {
            "foo1": "foo1.tar.gz"
        },
        "xj3_x86_64_gcc4.8.5": {
            "foo1": "foo1.tar.gz",
        },
        "misc": {
            "x.py": "~/.horizon/"
        }
    }
}

VERSION_JSON = {
    "host_package_version": "",
    "aarch_64": {
        "appsdk": [
            "",
            ""
        ],
        "bpu_predict": [
            "",
            ""
        ],
        "dnn": [
            "",
            ""
        ],
        "hobotsdk": [
            "",
            ""
        ],
        "image_utils": [
            "",
            ""
        ],
        "model_inference": [
            "",
            ""
        ],
        "rtsp_server": [
            "",
            ""
        ],
        "uvc_server": [
            "",
            ""
        ],
        "video_source": [
            "",
            ""
        ],
        "xproto": [
            "",
            ""
        ],
        "xstream": [
            "",
            ""
        ]
    },
    "x86_64_gcc4.8.5": {
        "bpu_predict": [
            "",
            ""
        ],
        "hobotsdk": [
            "",
            ""
        ],
        "xproto": [
            "",
            ""
        ],
        "xstream": [
            "",
            ""
        ]
    }
}
