# -*- coding: utf-8 -*-

#  Copyright (c) 2021 Horizon Robotics.All Rights Reserved.
#  #
#  The material in this file is confidential and contains trade secrets
#  of Horizon Robotics Inc. This is proprietary information owned by
#  Horizon Robotics Inc. No part of this work may be disclosed,
#  reproduced, copied, transmitted, or used in any way for any purpose,
#  without the express written permission of Horizon Robotics Inc.
#
import os
import click
import shutil
import ddk_vcs.utils as u
import ddk_vcs.conf as c

from collections.abc import Iterable

__VERSION__ = '0.2.1'

import tarfile
import yaml


def install_module(module_file: Iterable, platform: str, patch: bool = False):
    module_list = module_file
    package_install_path = c.XJ3_AARCH64_PATH if platform == 'aarch_64' else c.XJ3_X86_64_GCC_PATH
    package_install_list = c.aarch64_packages if platform == 'aarch_64' else c.x86_list_packages
    # 解析输入，依次对单个模块进行安装
    for module in module_list:
        if os.path.isfile(module) and str(module).endswith('.tar.gz'):
            tar_name = os.path.split(module)[-1]
            # 当为文件时检测文件名
            module_name, module_version = u.get_module_info_from_package(module)
            if module_name:
                # print(f'Start install {module_name}, version: {module_version}, platform: {platform}')
                if os.path.split(module)[0] == package_install_path:
                    print(f'The file {tar_name} already exists in the installation directory')
                    print('Please specify the version number directly for installation')
                    continue
                if module_name not in package_install_list:
                    print(f'Skip invalid module: {module_name}')
                    continue
                res = os.system(
                    f'cp {module} {package_install_path} && cd {package_install_path} && tar zxf {tar_name}')
                if not res:
                    # res 默认返回 0
                    u.update_version(
                        dict(platform=platform, module=module_name, version=module_version, md5=u.get_md5(module)[:10],
                             patch=patch)
                    )
                    print(f"{module_name} installed successfully, version: {module_version}, platform: {platform}")
                else:
                    print(f"{module_name} installed failed, please double check your input")
            else:
                raise ValueError(f'Input package invalid: {tar_name}')
        else:
            module_info = module.split("==")
            module_name = module_info[0]
            # 检测是否为支持的模块
            if module_name in c.aarch64_packages or module_name in c.x86_list_packages:
                # 若未包含版本号则默认安装最新版本
                if len(module_info) > 1 and not str(module).endswith('=='):
                    version = module_info[1]
                else:
                    version = u.get_latest_version(module_name, platform)
                # 检测是否有对应版本
                local_package_info = u.get_local_packages()[platform]
                package_name = f'{module_name}_{version}.tar.gz'
                if local_package_info.get(package_name):
                    if platform == 'aarch_64':
                        package_path = os.path.join(c.XJ3_AARCH64_PATH, package_name)
                    else:
                        package_path = os.path.join(c.XJ3_X86_64_GCC_PATH, package_name)
                    res = os.system(f'cd {package_install_path} && tar zxf {package_name}')
                    if not res:
                        u.update_version(
                            dict(platform=platform, module=module_name, version=version,
                                 md5=u.get_md5(package_path)[:10], patch=patch)
                        )
                        print(f"{module_name} installed successfully, version: {version}, platform: {platform}")
                    else:
                        print(f"{module_name} installed failed, please double check your input")
                else:
                    print(f'module {module_name} version {version} is not exist, please specify the location of the installation package')
            else:
                print(f'{module_name} is not support')


@click.group()
@click.version_option(version=__VERSION__, prog_name='DDK VCS')
def main():
    """
    Horizon Device Development Kit Version Control System
    """


@main.command(name='list', help='List installed packages.')
@click.option(
    '-p/--no-package',
    default=False,
    help='Show all existing packages(*.tar.gz) on host machine.'
)
def show_all_host_packages(p):
    show_packages = p
    if show_packages:

        # 先获取已安装的包信息和安装包(*.tar.gz)信息
        installed_package_info = u.get_installed_packages()
        local_package_info = u.get_local_packages()
        hp_version = installed_package_info.get('host_package_version')

        # 比较差异
        local_md5_set = set()
        installed_md5_set = set()

        local_md5_aarch_64_list = [module_info[1] for module_info in list(local_package_info.get('aarch_64').values())]
        local_md5_x86_64_gcc_list = [module_info[1] for module_info in
                                     list(local_package_info.get('x86_64_gcc4.8.5').values())]
        local_md5_set.update(local_md5_aarch_64_list)
        local_md5_set.update(local_md5_x86_64_gcc_list)
        aarch_64_md5_list = [module_info[1] for module_info in list(installed_package_info.get("aarch_64").values())]
        x86_64_gcc_list = [module_info[1] for module_info in
                           list(installed_package_info.get("x86_64_gcc4.8.5").values())]
        installed_md5_set.update(aarch_64_md5_list)
        installed_md5_set.update(x86_64_gcc_list)
        installed_md5_set.discard('')  # remove empty element
        if len(installed_md5_set) == 0:
            print('Cannot find any version of host package')
            exit(1)

        # If the installed_md5_set is not a subset of the local_md5_set
        not_modify = installed_md5_set.issuperset(local_md5_set)
        if not not_modify or installed_md5_set == local_md5_set:
            header = ['Platform', 'Local Package', 'Version', 'MD5']
            local_package_info_pared = sorted(
                [['aarch_64', k, v[0], v[1]] for k, v in local_package_info['aarch_64'].items()], key=lambda x: x[1])
            local_package_info_pared += sorted([['x86_64_gcc4.8.5', k, v[0], v[1]] for k, v in
                                                local_package_info['x86_64_gcc4.8.5'].items()], key=lambda x: x[1])
            if len(local_package_info_pared) > 0:
                local_package_info_pared.insert(0, header)
            pkg_strings, sizes = u.tabulate(local_package_info_pared)
            if len(local_package_info_pared) > 0:
                pkg_strings.insert(1, " ".join(map(lambda x: '-' * x, sizes)))
            print("Host package version: \033[0;34m%s\033[0m" % hp_version)
            print('The following packages versions')
            for val in pkg_strings:
                print(val)
        else:
            print("\033[0;33mWarning: the locally installed package has been modified\033[0m")

    else:
        header = ['Platform', 'Package', 'Version', 'MD5']
        installed_package_info = u.get_installed_packages()
        # host package version
        hp_version = installed_package_info.get('host_package_version')
        # 解析 aarch_64 version
        aarch_64_info = installed_package_info.get('aarch_64')
        x86_64_gcc_info = installed_package_info.get('x86_64_gcc4.8.5')
        aarch_64_info_parsed = sorted([['aarch_64', k, v[0], v[1]] for k, v in aarch_64_info.items()],
                                      key=lambda x: x[1])
        x86_64_gcc_info_parsed = sorted([['x86_64_gcc4.8.5', k, v[0], v[1]] for k, v in x86_64_gcc_info.items()],
                                        key=lambda x: x[1])
        # 合并信息
        pkg_info = aarch_64_info_parsed + x86_64_gcc_info_parsed
        if len(pkg_info) > 0:
            pkg_info.insert(0, header)
        pkg_strings, sizes = u.tabulate(pkg_info)
        if len(pkg_info) > 0:
            pkg_strings.insert(1, " ".join(map(lambda x: '-' * x, sizes)))
        print("Host package version: \033[0;34m%s\033[0m" % hp_version)
        print('The following packages versions')
        for val in pkg_strings:
            print(val)


@main.command(name='install', help='Install packages.')
@click.argument(
    'module_file',
    nargs=-1,
    required=True)
@click.option(
    '-p',
    '--platform',
    type=click.Choice(['aarch_64', 'x86_64_gcc4.8.5'], case_sensitive=False),
    required=True,
    help='Platform name')
def install_modules(module_file: Iterable, platform: str):
    platform_checklist = c.aarch64_packages if platform == 'aarch_64' else c.x86_list_packages
    module_files_list = list()
    for module in module_file:
        if str(module).endswith('.tar.gz'):
            module_files_list.append(module)
        elif not str(module).startswith('==') and '==' in str(module):
            module_files_list.append(module)
        elif str(module) in platform_checklist:
            module_files_list.append(module)
        else:
            print(f'Skip {module} as it is not support')
    platform = platform.lower()
    u.check_ddk_folder()
    install_module(module_files_list, platform)


@main.command(name='uninstall', help='Uninstall packages.')
@click.argument(
    'module',
    nargs=-1,
    type=str,
    required=True)
@click.option(
    '-p',
    '--platform',
    type=click.Choice(['aarch_64', 'x86_64_gcc4.8.5'], case_sensitive=False),
    required=True,
    help='Platform name')
def uninstall_module(module: Iterable, platform: str):
    platform = platform.lower()
    print(f'Start to uninstall modules, platform: {platform}')
    module_list = module
    installed_package_info = u.get_installed_packages()[platform]  # 获取已安装模块列表
    package_install_path = c.XJ3_AARCH64_PATH if platform == 'aarch_64' else c.XJ3_X86_64_GCC_PATH
    platform_checklist = c.aarch64_packages if platform == 'aarch_64' else c.x86_list_packages
    for module_name in module_list:
        # 检查模块是否已安装
        if u.check_module_status(module_name=module_name, platform=platform).get('installed'):
            module_info = installed_package_info.get(module_name)
            version = module_info[0]
            shutil.rmtree(os.path.join(package_install_path, module_name))
            # 修改version json中信息
            u.update_version(
                dict(platform=platform, module=module_name, version='', md5='', patch=False)
            )
            print(f'{module_name} uninstalled successfully, version: {version}, platform: {platform}')
        else:
            if installed_package_info.get(module_name) and module_name in platform_checklist:
                print(f"Skipping {module_name} as it is not installed")
                u.update_version(
                    dict(platform=platform, module=module_name, version='', md5='', patch=False)
                )
            else:
                print(f"Invalid module name: {module_name}")


@main.command(name='show', help='Show information about installed packages.')
@click.argument(
    'module',
    type=str,
    nargs=1,
    required=True)
@click.option(
    '-p',
    '--platform',
    type=click.Choice(['aarch_64', 'x86_64_gcc4.8.5'], case_sensitive=False),
    default=None,
    help='Platform name')
def show_module(module: str, platform: str):
    header = ['Platform', 'Package', 'Version', 'MD5']
    installed_package_info = u.get_installed_packages()
    hp_version = installed_package_info.get('host_package_version')
    platform_list = [platform.lower()] if platform is not None else ['aarch_64', 'x86_64_gcc4.8.5']
    info_list = list()
    for platform in platform_list:
        info = installed_package_info.get(platform).get(module)
        if info is not None:
            info = [platform, module] + info
            info_list.append(info)
    if len(info_list) < 1:
        print(f'{module} is not installed or the package does not exist')
        print('Use "ddk_vcs list" for all installed modules')
    else:
        info_list.insert(0, header)
        info_strings, sizes = u.tabulate(info_list)
        info_strings.insert(1, ' '.join(map(lambda x: '-' * x, sizes)))
        print("Host package version \033[0;34m%s\033[0m" % hp_version)
        print('The following packages versions')
        for val in info_strings:
            print(val)


@main.command(name='patch', help='Patch packages.')
@click.argument(
    'package',
    required=False,
    default=None,
    type=str)
@click.option(
    '-t',
    '--template',
    type=str,
    default=None,
    help='Generate patch template at specified location.')
@click.option(
    '-g',
    '--generate',
    type=str,
    default=None,
    help='Pack specified patch folder.')
def patch_host_package(package, template, generate):
    if package is not None:
        if u.check_patch_package(package):
            install_list = u.parse_patch_package(package)
            miss_list = list()
            for patch_info in install_list:
                platform = patch_info.get('platform')
                if platform != 'misc':
                    module_file = patch_info.get('file_path')
                    _module_name = patch_info.get('module_name')
                    if _module_name == '':
                        miss_list.append(os.path.split(module_file)[-1])
                    else:
                        install_module(
                            module_file=[module_file],
                            platform=platform,
                            patch=True
                        )
                elif platform == 'misc':
                    origin = patch_info.get('file_path')
                    dst = patch_info.get('dst_path')
                    dst_log = os.path.split(dst)[0]
                    file_name = patch_info.get('module_name')
                    try:
                        res = shutil.move(
                            src=origin,
                            dst=dst
                        )
                        print(f'{file_name} installed successful, location: {res}')
                    except FileNotFoundError as f:
                        print(f'{file_name} install failed because the destination folder {dst_log} does not exist')
                        miss_list.append(file_name)
                    except PermissionError as p:
                        print(f'{file_name} install failed because you do not have write access to the destination folder: {dst_log}')
                        miss_list.append(file_name)
                    except OSError as ose:
                        print(f'{file_name} install failed to the destination folder: {dst_log} with error: {ose}')
                        miss_list.append(file_name)
                else:
                    raise ValueError('invalid platform')
            print(f'Total: {len(install_list)}, Failed: {len(miss_list)}')
        else:
            print('Patch package input invalid')
    elif template is not None:
        abs_path = os.path.abspath(template)
        patch_path = os.path.join(abs_path, 'patch_package')
        if os.path.exists(patch_path):
            print('Patch package: patch_package is exist, please remove it')
            exit()
        elif os.path.exists(abs_path):
            os.mkdir(patch_path)
            with open(patch_path + '/config.yaml', 'w') as yaml_stream:
                yaml.dump(data=c.PATCH_CONFIG_YAML, stream=yaml_stream)
        else:
            print(f'Patch: {abs_path} is not exist')
            exit()
        print(f'Template generated successfully, location:{patch_path}')
    elif generate is not None:
        abs_path = os.path.abspath(generate)
        # base_path = os.path.dirname(abs_path)
        if os.getcwd() == abs_path:
            print(f'Please package outside the patch folder')
            exit()
        platform_list = ['misc', 'xj3_aarch64', 'xj3_x86_64_gcc4.8.5']
        # 首先解析yaml获取文件名列表，若有错则会停止
        patch_info = u.parse_patch_yaml(abs_path + '/config.yaml').get('packages')
        miss_list = list()
        patch_file_list = list()
        # 判断文件是否存在于patch文件夹内
        for platform in platform_list:
            if platform == 'misc':
                if patch_info.get(platform) is not None:
                    for file_name in patch_info.get(platform).keys():
                        file_path = os.path.join(abs_path, file_name)
                        if not os.path.exists(file_path):
                            miss_list.append(dict(platform=platform, file_name=file_name, abs_path=abs_path))
                        else:
                            patch_file_list.append(os.path.join(generate, file_name))
            else:
                if patch_info.get(platform) is not None:
                    for module_type, file_name in patch_info.get(platform).items():
                        # patch配置文件中只允许使用文件名填写
                        if r'/' in file_name:
                            print(f'{module_type} configuration is filled in incorrectly. Only file names are supported')
                            exit()
                        file_path = os.path.join(abs_path, file_name)
                        _module_name, _ = u.get_module_info_from_package(file_name)
                        if not os.path.exists(file_path) or _module_name == '':
                            miss_list.append(dict(platform=platform, file_name=file_name, abs_path=abs_path))
                        else:
                            module_name, module_version = u.get_module_info_from_package(file_name)
                            if module_name != '':
                                patch_file_list.append(os.path.join(generate, file_name))
                            else:
                                print(f'Package {file_name} is invalid')
                                exit()
        if len(miss_list) != 0:
            for info in miss_list:
                print(f'The {info.get("file_name")} was not found in the corresponding directory')
            exit()
        if len(patch_file_list) < 1:
            print(f'No modules found to package, Please check whether the module name is entered correctly')
            exit()
        print(f'Patch folder: {generate} verification passed')
        if os.path.exists('ddk_patch.tar.gz'):
            print('ddk_patch.tar.gz is exist, please remove it')
        else:
            patch_file_list.append(os.path.join(generate, 'config.yaml'))
            tar = tarfile.open('ddk_patch.tar.gz', 'w:gz')
            for file_path in patch_file_list:
                tar.add(file_path)
            tar.close()
            print('Patch file generated: ddk_patch.tar.gz')
    else:
        os.system('ddk_vcs patch --help')


@main.command(name='update_version', hidden=True)
@click.option(
    '-v',
    type=str,
    default='Unknown')
def update_hp_version(v):
    u.update_host_package_version(v)
