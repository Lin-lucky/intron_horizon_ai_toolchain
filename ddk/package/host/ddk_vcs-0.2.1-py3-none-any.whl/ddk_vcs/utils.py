# -*- coding: utf-8 -*-

#  Copyright (c) 2021 Horizon Robotics.All Rights Reserved.
#  #
#  The material in this file is confidential and contains trade secrets
#  of Horizon Robotics Inc. This is proprietary information owned by
#  Horizon Robotics Inc. No part of this work may be disclosed,
#  reproduced, copied, transmitted, or used in any way for any purpose,
#  without the express written permission of Horizon Robotics Inc.
#

import copy
import os
import json
import time

import yaml
import logging
import zipfile
import tarfile
import subprocess

import ddk_vcs.conf as hp
from itertools import zip_longest
from natsort import natsorted


class CompressedFileParse:
    """
    解析压缩文件，读取内部文件列表以及解压缩文件
    支持url形式
    """

    def __init__(self, file_path: str, url_mode=False) -> None:
        self.file_path = file_path
        self.url_mode = url_mode
        if not url_mode and not os.path.isfile(file_path):
            print('Tar package parsing failed')
            exit()
        self.file_name = os.path.split(file_path)[1]
        self.open_type = ''

    def tar_parse(self) -> list:
        tar = tarfile.open(self.file_path, self.open_type)
        inside_list = tar.getnames()
        tar.close()
        return inside_list

    def tar_extract(self, extract_list: list, output_dir: str) -> None:
        tar = tarfile.open(self.file_path, self.open_type)
        try:
            for extract_file in extract_list:
                tar.extract(extract_file, output_dir)
            tar.close()
        except Exception as e:
            logging.error(e)

    def tar_extract_file(self, extract_dict: dict, output_dir: str) -> None:
        """
        :extract_dict: 待提取信息dict，格式： {"filename": "tar file inside path"}
        :output_dir: 输出路径
        """
        tar = tarfile.open(self.file_path, self.open_type)
        try:
            for file_name, tar_info in extract_dict.items():
                file_path = os.path.join(output_dir, file_name)
                with open(file_path, 'wb') as tar_stream:
                    tar_stream.write(tar.extractfile(tar_info).read())
        except Exception as e:
            print(f'Tar file extrct erro: {e}')
            exit()

    def zip_parse(self) -> list:
        zip_file = zipfile.ZipFile(self.file_path, 'r')
        inside_list = zip_file.namelist()
        zip_file.close()
        return inside_list

    def zip_extract(self, extract_list: list, output_dir: str) -> None:
        zip_file = zipfile.ZipFile(self.file_path, 'r')
        try:
            for extract_file in extract_list:
                zip_file.extract(extract_file, output_dir)
            zip_file.close()
        except Exception as e:
            logging.error(e)

    def get_list(self, distinct: bool = False, prefix: str = None) -> list:
        """
        distinct: 去掉重复的文件夹层级
        """
        inside_list = list()
        if self.file_path.endswith('.gz'):
            self.open_type = 'r:gz'
            inside_list = self.tar_parse()
        elif self.file_path.endswith('.tar'):
            self.open_type = 'r:'
            inside_list = self.tar_parse()
        elif self.file_path.endswith('.zip'):
            inside_list = self.zip_parse()
        if distinct:
            inside_list.pop(0)
        return inside_list

    def extract_file(self, extract_list: list, out_put_dir: str) -> None:
        if self.file_path.endswith('.gz'):
            self.open_type = 'r:gz'
            self.tar_extract(extract_list=extract_list, output_dir=out_put_dir)

        elif self.file_path.endswith('.tar'):
            self.open_type = 'r:'
            self.tar_extract(extract_list=extract_list, output_dir=out_put_dir)

        elif self.file_path.endswith('.zip'):
            self.zip_extract(extract_list=extract_list, output_dir=out_put_dir)


def get_md5(file_path: str) -> str:
    """
    获取文件MD5
    :param file_path: str
    :return: str
    """
    command = ['md5sum', file_path]
    res = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
    md5 = res.stdout.split(' ')[0]
    return md5


def get_module_info_from_package(file_name: str) -> tuple:
    """
    对文件名切片获取模块名称和版本号
    :param file_name: 文件名
    :return: tuple(模块名, 版本)
    """
    file_name = os.path.split(file_name)[-1]
    module_name = '_'.join(file_name.split('_')[:-1])
    version = file_name.split('_')[-1].split(".tar.gz")[0]
    return module_name, version


def get_local_packages() -> dict:
    """
    获取本地host package文件夹中安装包的信息
    :return: {'platform': {'file_name': ['version', 'md5']}}
    """
    local_packages_info = {
        'aarch_64': {},
        'x86_64_gcc4.8.5': {},
    }
    # get local packages info
    platform = 'aarch_64'
    for folder_path in [hp.XJ3_AARCH64_PATH, hp.XJ3_X86_64_GCC_PATH]:
        package_install_list = hp.aarch64_packages if platform == 'aarch_64' else hp.x86_list_packages
        if not os.path.exists(folder_path):
            print(f"host package dir {folder_path} not exist!!!")
            exit(1)
        for file in os.listdir(folder_path):
            file_name, _ = get_module_info_from_package(file)
            if os.path.isfile(os.path.join(folder_path, file)) and file_name in package_install_list:
                version = file.split('_')[-1].split(".tar.gz")[0]
                md5 = get_md5(os.path.join(folder_path, file))
                local_packages_info[platform].update(
                    {
                        file: [version, md5[:10]]
                    }
                )
        platform = 'x86_64_gcc4.8.5'
    return local_packages_info


def get_installed_packages() -> dict:
    """
    获取安装好的host package模块信息
    :return:
    """
    check_version_json()
    with open(hp.HOST_PACKAGE_JSON, 'r') as f:
        installed_info = json.load(f)
    return installed_info


def check_ddk_folder() -> None:
    check_list = [
        hp.HORIZON_LIB_PATH,
        hp.DDK_PATH,
        hp.VCS_PATH,
        hp.PATCH_TMP_PATH,
        hp.XJ3_AARCH64_PATH,
        hp.XJ3_X86_64_GCC_PATH,
    ]
    for i in check_list:
        if not os.path.exists(i):
            os.mkdir(i)


def check_patch_package(patch_file: str) -> bool:
    """
    检查patch包是否符合规范，主要通过最外层是否有配置yaml来判断
    :param patch_file: str
    :return: bool
    """
    parser = CompressedFileParse(file_path=patch_file)
    file_info = parser.get_list(distinct=True)
    for internal_file in file_info:
        # 判断最外层是否有config.yaml
        if internal_file.split('/')[-1] == 'config.yaml' and len(internal_file.split('/')) == 2:
            return True
    return False


def check_version_json() -> bool:
    """
    检测版本信息json是否存在，不存在则创建
    :return: 返回是否存在bool
    """
    check_ddk_folder()
    json_path = hp.HOST_PACKAGE_JSON
    if os.path.isfile(json_path):
        # 检测是否符合规定
        file_ = open(hp.HOST_PACKAGE_JSON)
        try:
            json.load(file_)
            file_.close()
            return True
        except (json.decoder.JSONDecodeError, TypeError):
            file_.close()
            os.remove(hp.HOST_PACKAGE_JSON)
    with open(json_path, 'w') as json_stream:
        json_stream.write(
            json.dumps(hp.VERSION_JSON)
        )
    return False


def check_module_status(module_name: str, platform: str) -> dict:
    """
    检查对应模块的安装状态
    :param module_name: 模块名
    :param platform: 平台
    :return: dict
    """
    status = dict(installed=False)
    install_path = hp.XJ3_AARCH64_PATH if platform == 'aarch_64' else hp.XJ3_X86_64_GCC_PATH
    platform_checklist = hp.aarch64_packages if platform == 'aarch_64' else hp.x86_list_packages
    installed_modules = get_installed_packages().get(platform)
    # 检查是否为支持模块
    if module_name not in platform_checklist:
        return status
    # 检查本地是否安装
    module_path = os.path.join(
        install_path, module_name
    )
    if os.path.exists(module_path) and installed_modules.get(module_name):
        status["installed"] = True
    return status


def parse_patch_yaml(yaml_path: str) -> dict:
    """
    解析patch包中的yaml文件，转化为字典
    :param yaml_path: yaml文件路径
    :return: dict
    """
    invalid_list = list()
    platform_list = ['misc', 'xj3_aarch64', 'xj3_x86_64_gcc4.8.5']
    if not os.path.exists(yaml_path):
        print(f'Yaml file {yaml_path} does not exist')
        exit(1)
    try:
        with open(yaml_path, 'r') as yaml_stream:
            patch_info = yaml.load(yaml_stream, Loader=yaml.SafeLoader)
    except:
        print(f'Failed to analyse yaml document: {yaml_path}')
    # check module name
    try:
        for platform, modules in patch_info.get('packages').items():
            if platform not in platform_list:
                print(f'Invalid platform name: {platform}, right is {",".join(platform_list)}')
                exit()
    except:
        print(f'Failed to analyse yaml document: {yaml_path}')
        exit(1)
    if patch_info.get('packages').get('xj3_aarch64'):
        for key in patch_info.get('packages').get('xj3_aarch64').keys():
            if key not in hp.aarch64_packages:
                invalid_list.append(f'Invalid module name: {key}')
    if patch_info.get('packages').get('xj3_x86_64_gcc4.8.5'):
        for key in patch_info.get('packages').get('xj3_x86_64_gcc4.8.5').keys():
            if key not in hp.x86_list_packages:
                invalid_list.append(f'Invalid module name: {key}')
    if patch_info.get('packages').get('misc'):
        for key, value in patch_info.get('packages').get('misc').items():
            if value is None or value == '':
                invalid_list.append(f'Invalid path input for misc file: {key}')
    if len(invalid_list) > 0:
        for info in invalid_list:
            print(info)
        exit(1)
    return patch_info


def parse_patch_package(patch_file: str) -> list:
    """
    解压patch包，并且根据yaml中的信息返回对应的patch info
    :param patch_file: patch包路径
    :return: 包含每个patch信息的list
    """
    patch_yaml_key = {
        'xj3_aarch64': 'aarch_64',
        'xj3_x86_64_gcc4.8.5': 'x86_64_gcc4.8.5',
        'misc': 'misc'
    }
    patch_info_parsed = list()
    patch_file = CompressedFileParse(file_path=patch_file)
    extract_list = patch_file.get_list(distinct=False)
    tmp_path = os.path.join(hp.PATCH_TMP_PATH, 'patch_package')
    if not os.path.exists(tmp_path):
        os.mkdir(tmp_path)
    # parse file dict
    extract_dict = dict()
    for file_info in extract_list:
        file_name = os.path.split(file_info)[-1]
        extract_dict.update({file_name: file_info})
    patch_file.tar_extract_file(extract_dict=extract_dict, output_dir=tmp_path)
    config_path = os.path.join(tmp_path, 'config.yaml')
    patch_info = parse_patch_yaml(config_path)
    for alias, platform in patch_yaml_key.items():
        platform_info = patch_info.get('packages').get(alias)
        if platform_info is not None:
            for module_name, package_name in platform_info.items():
                dst_path = ''
                if platform != 'misc':
                    file_path = os.path.join(tmp_path, f'{package_name}')
                else:
                    dst_path = os.path.expanduser(os.path.join(package_name, module_name))
                    file_path = os.path.join(tmp_path, f'{module_name}')
                file_md5 = get_md5(file_path=file_path)
                patch_info_parsed.append(
                    {
                        'platform': platform,
                        'module_name': module_name,
                        'file_path': file_path,
                        'dst_path': dst_path,
                        'md5': file_md5
                    }
                )
    return patch_info_parsed


def update_host_package_version(version: str) -> None:
    """
    更新host package 版本号
    :param version: host package的大版本号
    :return:
    """
    # 先确认版本信息json是否存在
    check_version_json()
    # 获取现有版本信息
    old_info = get_installed_packages()
    new_info = copy.deepcopy(old_info)
    new_info['host_package_version'] = version
    json_parsed = json.dumps(new_info)
    # 写入文件
    with open(hp.HOST_PACKAGE_JSON, 'w') as json_stream:
        json_stream.write(json_parsed)


def update_version(module_info: dict) -> None:
    """
    升级对应模块版本号，若为patch模式则会增加后缀
    :param module_info: 模块信息，应为字典
    example:
    {
        "platform": "aarch_64",
        "module": "bpu_predict",
        "version": "",
        "md5": "",
        "patch": False
    }
    :return:
    """
    # 先确认版本信息json是否存在
    check_version_json()
    # 获取现有版本信息
    old_info = get_installed_packages()
    new_info = copy.deepcopy(old_info)
    # 从module info中解析参数
    platform = module_info.get('platform')
    module = module_info.get('module')
    version = module_info.get('version')
    md5 = module_info.get('md5')
    patch = module_info.get('patch')
    # 修改patch方式的版本号
    if patch:
        if old_info.get(platform).get(module):
            old_version = old_info.get(platform).get(module)[0]
        else:
            old_version = ''
        if 'patch' in old_version:
            version += '_patch' + str(int(old_version.split('patch')[-1]) + 1)
        else:
            version += '_patch1'
    module_info = [version, md5]
    new_info.get(platform)[module] = module_info
    json_parsed = json.dumps(new_info)
    # 写入文件
    with open(hp.HOST_PACKAGE_JSON, 'w') as json_stream:
        json_stream.write(json_parsed)


def get_latest_version(module_name: str, platform: str) -> str:
    """
    获取指定模块本地的最新版本号
    :param module: 模块名称
    :param platform: 平台名称
    :return: 返回值为版本号
    """
    # 首先获取本地所有包信息
    loacl_package_info = get_local_packages().get(platform)
    tmp_list = list()
    for package in loacl_package_info.keys():
        local_module_name, version = get_module_info_from_package(package)
        if module_name == local_module_name:
            tmp_list.append(version)
    if len(tmp_list) == 0:
        return None
    res = natsorted(tmp_list, reverse=True)
    return res[0]


def tabulate(rows) -> tuple:
    # type: (Iterable[Iterable[Any]]) -> Tuple[List[str], List[int]]
    """返回格式化行的列表和列宽度大小的列表。
    栗子：
    >>> tabulate([['Platform', 'Local Package', 'Version', 'MD5']])
    (['Platform Local Package Version MD5'], [8, 13, 7, 3])
    """
    rows = [tuple(map(str, row)) for row in rows]
    sizes = [max(map(len, col)) for col in zip_longest(*rows, fillvalue="")]
    table = [" ".join(map(str.ljust, row, sizes)).rstrip() for row in rows]
    return table, sizes
